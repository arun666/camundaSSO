package com.camunda.demo.filter.rest;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.rest.util.EngineUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

//@Component
//@WebFilter("/*")
public class CamundaFilter implements Filter {

	/*
	 * @Autowired RestTemplate restTemplate;
	 */

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		System.out.println("into the do filter");
		ProcessEngine engine = EngineUtil.lookupProcessEngine("default");
		String username = "demo";
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
		} else {
			username = principal.toString();
		}
		engine.getIdentityService().setAuthentication(username, getUserGroups(username));
		chain.doFilter(request, response);

	}

	private List<String> getUserGroups(String userId) {

		List<String> groupIds;

		org.springframework.security.core.Authentication authentication = SecurityContextHolder.getContext()
				.getAuthentication();
		System.out.println("into the get user groups");
		
		  String url="https://gturnquist-quoters.cfapps.io/api/random"; RestTemplate
		  restTemplate=new RestTemplate(); ResponseEntity<String> response =
		  restTemplate.getForEntity(url, String.class); System.out.println("response "
		  + response);
		 
		groupIds = authentication.getAuthorities().stream().map(res -> res.getAuthority()).map(res -> res.substring(5)) // Strip
																														// "ROLE_"
				.collect(Collectors.toList());

		return groupIds;

	}

}
